


<?php $__env->startSection('container'); ?>
<body>
   <div class="container">
   
       <div class="login">
        <?php if(session()->has('loginError')): ?>
        <div class="alert alert-danger" role="alert">
         
            <?php echo e(session('loginError')); ?>

        <?php endif; ?>
      
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert"> 
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
           <form method="post" action="/login">
            <?php echo csrf_field(); ?>
               <h1>Masuk</h1>
               <hr>
               <label for="email">Email</label>
               <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="name@example.com" name="email" autofocus required value="<?php echo e(old('ema')); ?>">
               <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <label for="">Kata Sandi</label>
               <input type="password" class="form-control" id="password" placeholder="Masukan Kata Sandi" name="password" required>
               <button type="submit"> Masuk</button>
               <p>
                   <label for="">Belum Punya Akun? <a href="/register">Daftar Di Sini</a></label>
               </p>
           </form>
       </div>
       <div class="right">
           <img src="<?php echo e(asset('images/bro.png')); ?>" alt="">
       </div>
   </div>
</body>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\MPPLProject\desaboard\resources\views/login/index.blade.php ENDPATH**/ ?>