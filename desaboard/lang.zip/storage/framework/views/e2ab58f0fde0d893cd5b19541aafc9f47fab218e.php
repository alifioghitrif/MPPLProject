
<?php $__env->startSection('container'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\MPPLProject\desaboard\resources\views/pertumbuhan.blade.php ENDPATH**/ ?>